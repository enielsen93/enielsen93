To install "Summarize Catchments Addin" click Addin.esriaddin. A toolbar is added to ArcGIS. It should be under Customize->Toolbars->Calculate Impervious Area.

To use the addon add a catchment feature layer to ArcGIS. Then select catchments and press the summary icon. 