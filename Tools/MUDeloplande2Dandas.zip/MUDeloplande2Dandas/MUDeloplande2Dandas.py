# -*- coding: utf-8 -*-
# Kode til at konvertere XML-filer fra Mike Urban af deloplande over til XML
# -filer for deloplande, der er klar til import i Dandas
# Husk at eksportere .XML fra Mike Urban med 

import re
import sys
if len(sys.argv)>1:
    infile = sys.argv[1]
else:
    infile = "NyeOplande.xml"
outfile = re.sub(".xml","_Dandas.xml",infile)

import numpy as np

# Tidspunktet nu, som bruges til opdaterings- og oprettelsesdato
import datetime
nu = datetime.datetime.now()

# Pakker til at anvende XML
from xml.dom import minidom
import xml.etree.ElementTree as ET  
# Vores XML-database fra Mike Urban
tree = ET.parse(infile)  

# Find XML-træ
tree.findall(".")

# Læs kategorien ms_Catchment_Geometry (x- og y-koordinater for catchment-polygoner)
rows = tree.findall("./Group[@Name='ms_Catchment_Geometry']/Rows/R")
GID = []
X = []
Y = []
Sqn = []
for row in rows:
	GID.append(row.get("GID"))
	X.append(row.get("X"))
	Y.append(row.get("Y"))
	Sqn.append(row.get("Sqn"))
	
# Læs kategorien ms_Catchment, som angiver areal og description-felt for catchments
rows = tree.findall("./Group[@Name='ms_Catchment']/Rows/R")
Area = []
Description =  []
ms_CatchmentMUID = []
for row in rows:
	Area.append(row.get("_Area"))
	Description.append(row.get("Description"))
	ms_CatchmentMUID.append(row.get("MUID"))
	if not Description[-1]:
		Description[-1] = " "
	
# Læs kategorien msm_HModA, som angiver befæstelsegrad for catchments
rows = tree.findall("./Group[@Name='msm_HModA']/Rows/R")
ImpArea = []
msm_HModAMUID = []
for row in rows:
	ImpArea.append(row.get("ImpArea"))
	msm_HModAMUID.append(row.get("CatchID"))
	
# Læs kategorien msm_CatchCon, som angiver knuderne, som catchments er tilkoblet
rows = tree.findall("./Group[@Name='msm_CatchCon']/Rows/R")
CatchID = []
NodeID = []
for row in rows:
	CatchID.append(row.get("CatchID"))
	NodeID.append(row.get("NodeID"))
	
# Begynd at skrive XML-fil
#Indledende junk
root = ET.Element("KnudeGroup")
root.set("xmlns","http://www.danva.dk/xml/schemas/dandas/20120102")
Referencesys = ET.SubElement(root,"Referencesys")
ET.SubElement(Referencesys,"KoordinatsysKode").text = "9"
ET.SubElement(Referencesys,"KotesysKode").text = "1"

# Begynd at tilføje knuder
allNodes = list(set(NodeID))
for nodei in range(len(allNodes)):
	Knude = ET.SubElement(root,"Knude")
	# Tilføj info om knuden
	Knude.set("Knudenavn",allNodes[nodei])
	ET.SubElement(Knude,"KnudeKode").text = "1"
	ET.SubElement(Knude,"DokKnudeItems")
	ET.SubElement(Knude,"KnudeGeometriItems")
	ET.SubElement(Knude,"KnudeVaerdiItems")
	ET.SubElement(Knude,"DaekselItems")
	ET.SubElement(Knude,"TilsluttetAdresseItems")
	
	# Tilføj deloplande til pågældende knude
	DeloplandItems = ET.SubElement(Knude,"DeloplandItems")
	catchmentidx = [i for i, x in enumerate(NodeID) if x == allNodes[nodei]]
	catchKnudeidx = 1
	for catchi in range(len(catchmentidx)):
		Delopland = ET.SubElement(DeloplandItems,"Delopland")
		Delopland.set("Deloplandnr","%d" % catchKnudeidx)
		ms_Catchmentidx = [i for i, x in enumerate(ms_CatchmentMUID) if x == CatchID[catchmentidx[catchi]]]
		msm_HModAidx = [i for i, x in enumerate(msm_HModAMUID) if x == CatchID[catchmentidx[catchi]]]
		ET.SubElement(Delopland,"Areal").text = "%1.4f" % ((float(Area[ms_Catchmentidx[0]]))/10000)
		ET.SubElement(Delopland,"BefaestelsePct").text = ImpArea[msm_HModAidx[0]]
		ET.SubElement(Delopland,"Bemaerkninger").text = Description[ms_Catchmentidx[0]]
		ET.SubElement(Delopland,"DatoOpdateret").text = nu.strftime("%Y-%m-%dT%H:%M:%S")
		ET.SubElement(Delopland,"DatoOprettet").text = nu.strftime("%Y-%m-%dT%H:%M:%S")
		ET.SubElement(Delopland,"Initialer").text = "Initialer"
		
		# Tilføj tekstfelt
		ET.SubElement(Delopland,"TekstjusteringKode").text = "4"
		ET.SubElement(Delopland,"Tekstvinkel").text = "0"
		GIDidx = [i for i, x in enumerate(GID) if x == CatchID[catchmentidx[catchi]]]
		# Beregn Midtpunkt til placering af tekstfelt
		ET.SubElement(Delopland,"XLabel").text = "%1.3f" % (np.mean([float(a) for a in np.take(X,GIDidx)]))
		ET.SubElement(Delopland,"YLabel").text = "%1.3f" % (np.mean([float(a) for a in np.take(Y,GIDidx)]))
		ET.SubElement(Delopland,"TekstFaktor").text = "1.00"
		if sys.argv[2].lower() == "s":
			ET.SubElement(Delopland,"TypeAfloebKode").text = "1"
		elif sys.argv[2].lower() == "r":
			ET.SubElement(Delopland,"TypeAfloebKode").text = "2"
		elif sys.argv[2].lower() == "f":
			ET.SubElement(Delopland,"TypeAfloebKode").text = "3"
		elif sys.argv[2].lower() == "m":
			ET.SubElement(Delopland,"TypeAfloebKode").text = "3"
		
		
		
		# Tilføj geometri til delopland
		DeloplandKoordItems = ET.SubElement(Delopland,"DeloplandKoordItems")
		for GIDi in range(len(GIDidx)):
			DeloplandKoord = ET.SubElement(DeloplandKoordItems,"DeloplandKoord")
			DeloplandKoord.set("Sortering","%d" % (GIDi+1))
			ET.SubElement(DeloplandKoord,"Xkoordinat").text = X[GIDidx[GIDi]]
			ET.SubElement(DeloplandKoord,"Ykoordinat").text = Y[GIDidx[GIDi]]
		
		# Delopland-indeks
		catchKnudeidx += 1
		
# Tilføj junk til slut
ET.SubElement(root,"KompleksBygvaerkGroup")
ET.SubElement(root,"BroendkatTopGroup")
ET.SubElement(root,"BroendkatVaegGroup")
ET.SubElement(root,"BroendkatBundGroup")
ET.SubElement(root,"BroendkatBundGroup")
ET.SubElement(root,"OprindelseGroup")
ET.SubElement(root,"DokumentGroup")
ET.SubElement(root,"FirmaGroup")
ET.SubElement(root,"VejGroup")
ET.SubElement(root,"DeklarationGroup")
ET.SubElement(root,"EjerlavGroup")
ET.SubElement(root,"LokalitetGroup")
ET.SubElement(root,"RecipientGroup")
ET.SubElement(root,"EjerfordelingGroup")

# Skriv XML-fil
with open(outfile,"w+") as f:
	f.write(minidom.parseString(ET.tostring(root)).toprettyxml())