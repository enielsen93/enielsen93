# -*- coding: utf-8 -*-
# Kode til at konvertere XML-filer fra Mike Urban af deloplande over til XML
# -filer for deloplande, der er klar til import i Dandas

import re
import sys
#infile = sys.argv[1]
infile = r"K:\Hydrauliske modeller\Makroer & Beregningsark\MU2Dandas\LyngsoSeparat.xml"
outfile = re.sub(".xml","_KnuderDandas.xml",infile)

import numpy as np

# Tidspunktet nu, som bruges til opdaterings- og oprettelsesdato
import datetime
nu = datetime.datetime.now()

# Pakker til at anvende XML
from xml.dom import minidom
import xml.etree.ElementTree as ET  
# Vores XML-database fra Mike Urban
tree = ET.parse(infile)  

# Find XML-træ
tree.findall(".")

typeAfloebKode = "2"

# Læs kategorien ms_Catchment_Geometry (x- og y-koordinater for catchment-polygoner)
rows = tree.findall("./Group[@Name='msm_Node']/Rows/R")
X = []
Y = []
BK = []
TK = []
Diameter = []
MUID = []

for row in rows:
    X.append(row.get("_X"))
    Y.append(row.get("_Y"))
    BK.append(row.get("InvertLevel"))
    TK.append(row.get("GroundLevel"))
    Diameter.append(row.get("Diameter"))
    MUID.append(row.get("MUID"))

# Begynd at skrive XML-fil
#Indledende junk
root = ET.Element("KnudeGroup")
root.set("xmlns","http://www.danva.dk/xml/schemas/dandas/20120102")
Referencesys = ET.SubElement(root,"Referencesys")
ET.SubElement(Referencesys,"KoordinatsysKode").text = "9"
ET.SubElement(Referencesys,"KotesysKode").text = "1"

# Begynd at tilføje knuder
for nodei in range(len(MUID)):
    Knude = ET.SubElement(root,"Knude")
    # Tilføj info om knuden
    Knude.set("Knudenavn",MUID[nodei])
    ET.SubElement(Knude,"KnudeKode").text = "1"
    ET.SubElement(Knude,"FormKode").text = "1"
    ET.SubElement(Knude,"KategoriAfloebKode").text = "1"
    ET.SubElement(Knude,"Bundkote").text = BK[nodei]
    ET.SubElement(Knude,"Terraenkote").text = TK[nodei]
    ET.SubElement(Knude,"DiameterBredde").text = "%1.0f" % (float(Diameter[nodei])*1e3)
    ET.SubElement(Knude,"KnudeKode").text = "1"
    ET.SubElement(Knude,"XKoordinat").text = X[nodei]
    ET.SubElement(Knude,"YKoordinat").text = Y[nodei]
    ET.SubElement(Knude,"DokKnudeItems")
    ET.SubElement(Knude,"KnudeGeometriItems")
    ET.SubElement(Knude,"KnudeVaerdiItems")
    ET.SubElement(Knude,"TypeAfloebKode").text = typeAfloebKode
    daekselitem = ET.SubElement(Knude,"DaekselItems")
    daekselitem1 = ET.SubElement(daekselitem,"Daeksel")
    daekselitem1.set("Daekselnr","1")
    ET.SubElement(daekselitem1,"Daekselkote").text = TK[nodei]
    ET.SubElement(daekselitem1,"DiameterBredde").text = "%1.0f" % (float(Diameter[nodei])*1e3)
    ET.SubElement(Knude,"TilsluttetAdresseItems")
    broend = ET.SubElement(Knude,"Broend")
    ET.SubElement(broend,"BroendKode").text = "1"
        
# Tilføj junk til slut
ET.SubElement(root,"KompleksBygvaerkGroup")
ET.SubElement(root,"BroendkatTopGroup")
ET.SubElement(root,"BroendkatVaegGroup")
ET.SubElement(root,"BroendkatBundGroup")
ET.SubElement(root,"BroendkatBundGroup")
ET.SubElement(root,"OprindelseGroup")
ET.SubElement(root,"DokumentGroup")
ET.SubElement(root,"FirmaGroup")
ET.SubElement(root,"VejGroup")
ET.SubElement(root,"DeklarationGroup")
ET.SubElement(root,"EjerlavGroup")
ET.SubElement(root,"LokalitetGroup")
ET.SubElement(root,"RecipientGroup")
ET.SubElement(root,"EjerfordelingGroup")

# Skriv XML-fil
with open(outfile,"w+") as f:
    f.write(minidom.parseString(ET.tostring(root)).toprettyxml())
    
outfile = re.sub(".xml","_LedningerDandas.xml",infile)    

rows = tree.findall("./Group[@Name='msm_Link']/Rows/R")
fromnode = []
tonode = []
uplevel = []
downlevel = []
length = []
slope = []
pipediameter = []
MUID = []

for row in rows:
    fromnode.append(row.get("_FromNodeID"))
    tonode.append(row.get("_ToNodeID"))
    uplevel.append(row.get("UpLevel_C"))
    downlevel.append(row.get("DwLevel_C"))
    length.append(row.get("Length_C"))
    slope.append(row.get("Slope_C"))
    pipediameter.append(row.get("Diameter"))
    MUID.append(row.get("MUID"))

# Begynd at skrive XML-fil
#Indledende junk
root = ET.Element("LedningGroup")
root.set("xmlns","http://www.danva.dk/xml/schemas/dandas/20120102")
Referencesys = ET.SubElement(root,"Referencesys")
ET.SubElement(Referencesys,"KoordinatsysKode").text = "9"
ET.SubElement(Referencesys,"KotesysKode").text = "1"

# Begynd at tilføje ledninger
for ledningi in range(len(MUID)):
    ledning = ET.SubElement(root,"Ledning")
    # Tilføj info om knuden
    ledning.set("OpstroemKnudenavn",fromnode[ledningi])
    ledning.set("NedstroemKnudenavn",tonode[ledningi])
    ledning.set("DobbeltlednNr","1")
    ET.SubElement(ledning,"KategoriAfloebKode").text = "1"
    ET.SubElement(ledning,"LednfunktionKode").text = "1"
    ET.SubElement(ledning,"StatusKode").text = "1"
    ET.SubElement(ledning,"TypeAfloebKode").text = typeAfloebKode
    
    delLedningItems = ET.SubElement(ledning,"DelLedningItems")
    delledningitem1 = ET.SubElement(delLedningItems,"DelLedning")
    delledningitem1.set("OpstroemKnudenavn",fromnode[ledningi])
    delledningitem1.set("NedstroemKnudenavn",tonode[ledningi])
    ET.SubElement(delledningitem1,"BundloebskoteNedst").text = downlevel[ledningi]
    ET.SubElement(delledningitem1,"BundloebskoteOpst").text = uplevel[ledningi]
    ET.SubElement(delledningitem1,"DiameterIndv").text = "%1.0f" % ((float(pipediameter[ledningi]))*1000)
    ET.SubElement(delledningitem1,"Handelsmaal").text = "%1.0f" % ((float(pipediameter[ledningi]))*1000)
    ET.SubElement(delledningitem1,"Fald").text = "%1.3f" % ((float(slope[ledningi]))*10)
    ET.SubElement(delledningitem1,"Laengde").text = length[ledningi]
    ET.SubElement(delledningitem1,"TvaersnitKode").text = "1"
    
# Skriv XML-fil
with open(outfile,"w+") as f:
    f.write(minidom.parseString(ET.tostring(root)).toprettyxml())