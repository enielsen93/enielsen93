# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 16:03:22 2018

@author: eni
"""

from xml.dom import minidom
import xml.etree.ElementTree as ET  
import re
import numpy as np
import matplotlib.pyplot as plt
plt.close("all")

#import archook #The module which locates arcgis
#archook.get_arcpy()
#import arcpy

with open("J:\Bruger\Eni\dgn\knuder.xml","r") as infile:
    txt = infile.read()
    txt = re.sub(r' xmlns="[^"]+"',"",txt)
tree = ET.fromstring(txt)
		
nodes = tree.findall("Knude")


x = np.zeros((len(nodes)))
y = np.zeros((len(nodes)))
for nodei in range(len(nodes)):
    x[nodei] = float(nodes[nodei].find("XKoordinat").text) 
    y[nodei] = float(nodes[nodei].find("YKoordinat").text)
    
plt.plot(x,y,'o')

with open("J:\Bruger\Eni\dgn\ledninger.xml","r") as infile:
    txt = infile.read()
    txt = re.sub(r' xmlns="[^"]+"',"",txt)
tree = ET.fromstring(txt)
		
links = tree.findall("Ledning")

xstart = np.zeros((len(nodes)))
xend = np.zeros((len(nodes)))
ystart = np.zeros((len(nodes)))
yend = np.zeros((len(nodes)))
for linki in range(len(links)):
    fromnodei = 