# -*- coding: utf-8 -*-
"""
Created on Thu Aug  2 08:41:19 2018

@author: eni
"""

import arcpy

#oldCatchmentsFile = r"C:\Dokumenter\Soholt\Soeholt_1.2_geo.mdb\mu_Geometry\ms_Catchment"
#newCatchmentsFile = r"C:\Dokumenter\Soholt\Soholt_Baek_ET_KS_4.mdb\mu_Geometry\ms_Catchment"
#
#oldCatchments = {}
#with arcpy.da.SearchCursor(oldCatchmentsFile, ['MUID','SHAPE@AREA']) as catchmentcursor:
#    for row in catchmentcursor:
#        oldCatchments[row[0]] = row[1]
#
#changedCatchments = []
#with arcpy.da.SearchCursor(newCatchmentsFile, ['MUID','SHAPE@AREA']) as catchmentcursor:
#    for row in catchmentcursor:
#        matchMUID = [row[0] for a in oldCatchments.keys() if row[0]==a]
#        if not matchMUID:
#            changedCatchments.append(row[0])
#        elif oldCatchments[matchMUID[0]] != row[1]:
#            changedCatchments.append(row[0])
#
#print "%1.0f catchments changed (%1.1f%s)" % (len(changedCatchments),float(len(changedCatchments))/len(oldCatchments)*100,"%")
#where_clause="""MUID IN (%s)""" % ("'" + "', '".join(changedCatchments) + "'")

#newCatchmentsFile = r"C:\Dokumenter\Soholt\Soholt_Baek_ET_KS_4.mdb\msm_HModA"
#
#changedCatchments = []
#with arcpy.da.SearchCursor(newCatchmentsFile, ['MUID','ImpArea']) as catchmentcursor:
#    for row in catchmentcursor:
#        if row[1]%5==0:
#            changedCatchments.append(row[0])
#
##print "%1.0f catchments changed (%1.1f%s)" % (len(changedCatchments),float(len(changedCatchments))/len(oldCatchments)*100,"%")
#where_clause="""MUID IN (%s)""" % ("'" + "', '".join(changedCatchments) + "'")

hashes = []
with arcpy.da.SearchCursor("C:\Dokumenter\catchintsec.shp", ['SHAPE@WKT']) as catchmentcursor:
    for row in catchmentcursor:
        hashes.append(hash(row[0]))
duplicates = set([x for x in hashes if hashes.count(x) > 1])

duplicatesDict = {}
for dup in duplicates:
    duplicatesDict[dup] = 0

with arcpy.da.UpdateCursor("C:\Dokumenter\catchintsec.shp", ['SHAPE@WKT','FID']) as catchmentcursor:
    for row in catchmentcursor:
        if hash(row[0]) in duplicatesDict.keys():
            if duplicatesDict[hash(row[0])] == 1:
                catchmentcursor.deleteRow()
            duplicatesDict[hash(row[0])] = duplicatesDict[hash(row[0])] + 1 
        